# Hospital-Management
I developed Hospital Management using HTML, JS and CSS. 
The Main objective of this Project is to Handle Appointements and Reports in the Hospital every single day.
Specially during these Covid Pandaemic times, to handle crowd in hospitals social distancing is must.
So its very important to handle all Reports and Appointments on any particular date and time. 
